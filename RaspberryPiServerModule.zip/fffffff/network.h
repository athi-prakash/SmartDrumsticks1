
#ifndef NETWORK_H
#define NETWORK_H

#include <stdio.h>


extern void NetworkStartup( int port );

extern void WaitForConnect();

extern int OpenClientSocket();

#endif
