# READ ME FOR THE RASPBERRY PI MODULE

## Description
The raspberry pi behaves as the server for the drumstick application.
Using tethering or a common wifi network, the android phone can connect to the server
by opening a socket on port 8080 with the static ip 192.168.43.10.

Every time the application sends the raspberry pi an IP message, the LED will blink.

## Set-up
To set-up the software, connect the raspberry pi to the android hotspot. 
To start the application, run:

> ./LEDServer 

From /home/pi/ directory of the raspberry pi. Eventually this will become automatic when the pi power turns on.


## Hardware set-up. 

The LED's negative terminal is connected via a 330Ohm resistor to the GPIO17 pin of the raspberry pi. 
The positive terminal is wired to the 5V pin of the raspberry pi.

The raspberry pi has been tested with both a standard wall charger for any micro-usb cellphone as well as a battery pack.