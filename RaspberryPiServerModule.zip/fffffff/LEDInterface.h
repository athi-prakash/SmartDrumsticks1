#ifndef LED_INTERFACE_H
#define LED_INTERFACE_H


extern void initBlinker(int);
extern void blinkLED(int,int);

#endif
