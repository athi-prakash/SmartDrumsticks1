/* 
 * File: LedServer.c
 * Author: Scott Bailey
 * Student ID: B00636779
 * Purpose: This file contains LED server. It lets the main app connect to the raspberry pi.
 *          Every time a message is received from the app, the LED blinks.
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <sys/sendfile.h>
#include <sys/stat.h>
#include <sys/time.h>
#include <fcntl.h>
#include "network.h"
#include "LEDInterface.h"

// Create a static variable for the 255 byte message buffer.
static char r_buffer[255];

#define SWS_BUFFER_SIZE 255

// Introduce the file descriptor integer of the request.
static int client_socket;

// Default not to have verbose output from the server. 
// Can be set via command line argument 2 '-v' for verbose.
static int verbose_enabled = 0;

/*
 * The main function takes one command line argument which is the port number to
 * connect bind the network to. 
 */
int main(int argc, char *argv[])
{

	initBlinker(0);
	// Invalid port id that must be overridden by argv[1].
	int portId = -1; 
	
	// m_len will hold the length of the message.
	size_t m_len = 0;
	
	// Initialize the buffer as NUL.
	memset(r_buffer, '\0', SWS_BUFFER_SIZE);
	
	// Initialise the client socket file descriptor as invalid.
	client_socket = -1;
	int result = -1;
	// If there are only two arguments (inc. file name) the other must be a valid
	// port number or else the server will quit.
	if (argc == 2) {
		result = sscanf(argv[1], "%d", &portId);
		
		if (result != 1 ){
			printf("\nThe port id entered was not a valid integer.\n");
			return -1;
		}
	}
	
	// If there are three arguments there should be a valid port number
	// and a valid flag for enabling verbose mode.
  else if (argc == 3){
		result = sscanf(argv[1], "%d", &portId);
		if (result != 1 ){
			if (verbose_enabled)
				printf("\nThe port id entered was not a valid integer.\n");
			return -1;
		}
		if (strcmp(argv[2], "-v") == 0){
			verbose_enabled = 1;
		}
		else{
			if (verbose_enabled)
				printf("\nIgnoring argument 2: '%s', use -v for verbose.\n", argv[2]);
		}
	}	
	else {
		if (verbose_enabled)
			printf("The port number is a required input to this program. %d\n", argc);
		return -1;
	}
	
	if (!((portId < 65335) && (portId > 1024))) {
		if (verbose_enabled)
			printf("You have entered %d, an invalid port for user level processes.\n"
									 "Please choose a port between 1024 and 65335.\n", portId);
		return -1;
	}
	
	// NetworkStartup will bind the server to the port through a server socket.
	NetworkStartup( portId );
	while(1){
		if (verbose_enabled)
			printf("\nWaiting for a client connection to port %d...\n", portId);

		// WaitForConnect() will hold the program until a client accesses the port.
		WaitForConnect();
		
		// OpenClientSocket() will create a socket and return a file descriptor for r/w.
		client_socket = OpenClientSocket();
		if (client_socket < 0){
			printf("Network error \n");
			break;
		}
                  struct timeval t;    
                  t.tv_sec = 0;
                  
                  setsockopt(client_socket, SOL_SOCKET, SO_RCVTIMEO, (const void *)(&t), sizeof(t)); 			
		while(1) {
                        printf("Reading from socket %d.\n",client_socket);
		
			// Read in the message, or at least the first 254 bytes.
			m_len = recv(client_socket, r_buffer, SWS_BUFFER_SIZE-1, 0);

			// for now every message will cause a blink.
			// Eventually buffering should be implemented to reduce network latency.
			if (m_len > 0){
				// Blink Pin 0  == GPIO 17 on by setting it low for 200ms then back up to high. 
				// LED is set-up using the 5V pin as the power source and the IO pin as the sink so that eventually
				// batteries could be used to reduce board power consumption.
				blinkLED(0, 200);
                printf("Received a message %s.\n", r_buffer);
			} else{
				if (verbose_enabled)
					printf("\nFailed to read from socket %d.\n", client_socket);
                // Dead connection, wait for a new one.
				close(client_socket);
				break;
			}

		}
	}
	return 0;
}
