#include <wiringPi.h>
#include "LEDInterface.h"

#include <stdio.h>

void initBlinker(int pin)
{
    wiringPiSetup();
    pinMode(0,OUTPUT);

    digitalWrite(pin, LOW); delay (500);
    digitalWrite(pin, HIGH); delay (500);
}

void blinkLED(int pin, int delayTime)
{
    digitalWrite(pin, LOW); delay (delayTime);
    digitalWrite(pin, HIGH); delay (delayTime);
}


